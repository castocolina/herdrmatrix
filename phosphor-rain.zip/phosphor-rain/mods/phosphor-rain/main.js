import { View, div } from "gpui-kit";
import { h_flex, v_flex } from "gpui-base";
import { theme, agents } from "herdr";

// Lluvia digital: cada celda cicla glifos con .frames (animación nativa, sin timers).
const GLYPHS = "ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎ0123456789Z:.=*+<>";
const COLS = 22;
const ROWS = 9;
const CELL = 11;   // px
const TRAIL = 4;   // largo de la estela
const PERIOD = 16; // frames por ciclo

// PRNG determinista: patrón estable entre renders.
function rng(seed) {
  let s = seed >>> 0;
  return () => ((s = (s * 1664525 + 1013904223) >>> 0) / 4294967296);
}

function buildColumn(c) {
  const r = rng(c * 7919 + 17);
  const offset = Math.floor(r() * PERIOD);
  const speed = 70 + Math.floor(r() * 80); // ms por frame
  const cells = [];
  for (let row = 0; row < ROWS; row++) {
    const frames = [];
    for (let f = 0; f < PERIOD; f++) {
      const d = (f - row - offset + PERIOD * 4) % PERIOD;
      frames.push(d < TRAIL ? GLYPHS[Math.floor(r() * GLYPHS.length)] : " ");
    }
    cells.push(frames);
  }
  return { speed, cells, pulse: 900 + Math.floor(r() * 900) };
}

const RAIN = Array.from({ length: COLS }, (_, c) => buildColumn(c));

export default class PhosphorRain extends View {
  render() {
    const t = theme();
    // Agente bloqueado: la lluvia se tiñe de rojo neón.
    const blocked = agents().some((a) => a.status === "blocked");
    const color = blocked ? t.blocked : t.accent;

    return v_flex().id("root").size_full().overflow_hidden()
      .items_center().justify_center()
      .child(h_flex().gap(1).children(RAIN.map((col, c) =>
        v_flex().id(`c${c}`).w(CELL)
          .loop("opacity", { from: 0.35, to: 1, period: col.pulse })
          .children(col.cells.map((frames, row) =>
            div().id(`c${c}r${row}`).h(CELL + 3).w(CELL)
              .text_size(CELL).text_color(row === ROWS - 1 ? t.foreground : color)
              .frames(frames, col.speed))))));
  }
}
