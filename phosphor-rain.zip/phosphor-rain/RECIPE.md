# Phosphor Rain

Herdr in green-phosphor neon on near-black: the default sidebar (spaces, agents) with a column of animated digital rain at its bottom, pill tabs, and every pane as a dark card that lights up with a neon-green border when focused. When any agent is blocked, the rain turns neon red.

![Phosphor Rain](preview.png)

## What you see

- **Background:** `mods/phosphor-rain/backgrounds/phosphor-rain.jpg` (2560×1600, cover). It shows digital rain in three depths on a `#001a07` → `#000300` gradient, with scanlines and a vignette. It shows through the 70%-opaque pane cards and the 88%-opaque sidebar.
- **Program icons ("operators"):** five original neon avatars in `mods/phosphor-rain/icons/`, mapped through `programs.json`: Root (robot, `claude`), Byte (circuit cat, `codex`), Moth (`opencode`), Glitch (pixel ghost, `cursor`) and Hoot (hex-eyed owl, `shell`). They appear wherever Herdr shows program icons: tabs, the agents list and pane headers.
- **Sidebar (left, 240px, `chrome` `#010702`):** shipped `spaces` on top, shipped `agents` below, and a 150px `rain` block at the bottom: 22 columns × 9 rows of 11px half-width katakana, digits and symbols falling in streaks of 4, in `accent` `#00ff41`; the bottom row is `foreground` `#9dffb4`.
- **Tabs (top, 30px):** shipped `tabs` mod.
- **Panes:** 6px padding and gap, radius 4, `background` `#020a04`, 1px border `#0d3b1c`; the focused pane's border is `#00ff41`. A single pane is framed too (`lone: true`).
- **Terminal:** JetBrains Mono 14, padding `[10, 8]`, opacity 0.92, cursor `#00ff41`, selection `#0f4d24`. The UI font is also JetBrains Mono.
- **ANSI:** green `#00ff41`, cyan `#00ffd5`, lime-yellow `#d4ff3a`, red `#ff3b5c`, blue `#00b3ff`, violet `#b26bff` (full list in `themes/phosphor-rain.json`).

## How it behaves

- Agent colors: working `#00ff41`, done `#00ffd5`, blocked `#ff3b5c`, idle `#2a7a44`.
- Any agent `blocked` → the rain glyphs switch to `blocked` red until no agent is blocked.
- Each rain column falls at its own speed (70–150 ms per frame) and pulses in opacity (0.35–1, 0.9–1.8 s period).
- The rain block can be resized by dragging its top divider (0–400px) or hidden with `layout.toggle {id: "rain"}`.

## Built from

- `layouts/phosphor-rain.json`: root `row` → `sidebar` column (`spaces`, `agents`, `rain` → mod `phosphor-rain`) and `work` column (`tabs`, `main` → `{ "tab": "active" }` with pane frames). Root sets `theme: "phosphor-rain"`, `colors`, fonts, `terminal_padding`, `terminal_opacity`, gradient `background` and `preview`.
- `themes/phosphor-rain.json`: copy it to the home's `themes/` too. Named like the layout, so Settings offers it only there.
- `mods/phosphor-rain/`: one view. Uses `theme()` and `agents()` only. The animation is native: `.frames(glyphs, ms)` per cell and `.loop("opacity", …)` per column. No timers, no `exec`, no network, no file access.

- `programs.json`: merge its entries into the person's own `programs.json` (field by field). Do not overwrite the file.

## Watch out

- The background and icons live inside `mods/phosphor-rain/`, so they travel with the mod folder. The paths are relative to `~/.config/herdr-app`.
- Panes use `#020a04b3` and `terminal_opacity` 0.82 so the background shows through. Raise both for more legibility.

- The glyph frames come from a seeded PRNG at module load, so the pattern is stable across renders and reloads.
- Half-width katakana (U+FF71–U+FF9D) are not in JetBrains Mono. They rely on system font fallback. If they show as boxes, swap `GLYPHS` for ASCII.
- 198 animated cells. Lower `COLS`/`ROWS` on slow GPUs.
- The shipped `spaces`, `agents` and `tabs` mods are used as-is, and they follow the theme on their own.

## Done when

- `herdr-app check ~/.config/herdr-app/mods/phosphor-rain` passes.
- `herdr-app do layout.switch '{"name":"phosphor-rain"}'` shows the green theme, and `layout.error` does not exist.
- The rain animates while nothing else changes, and `herdr-app status` shows no mod errors.
- An agent going `blocked` turns the rain red. Answering it turns the rain green again.
